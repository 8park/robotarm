Thank you very much for your every contributions!

I'm very glad to see so many changes and advances from the earlier SDK.

While getting lots of information from you, the entire network in repo doesn't seem very clear
so the work was very hard to be carried out so far.

Hence, I will update some GUIDELINES that is very necessary to get your ideas be MERGED.

1. After every release, there is a 'develop' branch. To make your idea be accepted on the next release,
YOU SHOULD GET PULL REQUEST BASED ON THE 'DEVELOP' BRANCH, NOT THE 'MASTER' BRANCH!!
All pull requests based on 'master' branch will be 'suspended' or 'won't fix', so make sure before the pull request.

2. I'm hoping that many users can list up on the [CONTRIBUTORS](https://github.com/ROBOTIS-GIT/DynamixelSDK/graphs/contributors).
Seriously, I don't want to get your idea as my name but as your name. However, if your idea is left as based on 'develop branch' or idle,
I can't do anything but upload your idea as my name.

Thank you every time again, and let's make the source better to get many users happy while make Dynamixel applications.

2017.12.01 doc ver 1.0.1
